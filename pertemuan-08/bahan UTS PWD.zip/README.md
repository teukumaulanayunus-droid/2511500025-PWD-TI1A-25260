# pertemuan-08

silahkan sesuaikan dengan milik kalian masing-masing:<br><br>
Hari ini, Rabu 12.NOV.2025, saya:<br>
NIM: 0344300002<br>
Nama: Yohanes Setiawan Japriadi<br>
Kelompok: TI1A<br>
<br>
Proses saya mengerjakan UTS ini sebagai berikut:<br>
<ol>
  <li>silahkan diisi sesuai proses pengerjaan kalian masing-masing</li>
</ol>