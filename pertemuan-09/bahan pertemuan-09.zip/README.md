# pertemuan-09

<ol>
  <li>Hasil UTS untuk bahan pertemuan-09</li>
  <li>Membuat form untuk biodata sederhana mahasiswa</li>
  <li>styling section biodata</li>
  <li>styling section biodata beres</li>
  <li>tangkap post dan buat session untuk form biodata</li>
  <li>session form biodata beres</li>
  <li>tangkap session dari file proses</li>
  <li>tangkap session dari file proses selesai</li>
  <li>echo session ke nilai label section contact</li>
  <li>echo session ke nilai label section contact selesai</li>
</ol>